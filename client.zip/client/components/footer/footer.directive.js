// 'use strict';
//
// angular.module('bootstrapAppApp')
//   .directive('footerDiv', function() {
//     return {
//       templateUrl: 'components/footer/footer.html',
//       restrict: 'E',
//       link: function(scope, element) {
//         element.addClass('footerDiv');
//       }
//     };
//   });
