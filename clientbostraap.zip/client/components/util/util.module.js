'use strict';

angular.module('bootstrapAppApp.util', []);
